document.addEventListener("keydown", (e)=>{
    var downKey=e.keyCode;
    var keyRepeat=e.repeat;

    if(downKey==27 && keyRepeat!=true){
        esc();
    };

    if(downKey==69 && keyRepeat!=true){
        openInv();
    };

});