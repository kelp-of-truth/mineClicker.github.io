function furnace_get() {
    menus[1] = 1;
    if (selectedMenu == 1) {
        changeMenu("furnace.webp", 1);
    };

}







function get_stone_pickaxe() {
    pickaxePower = 445;
};

function get_iron_pickaxe() {
    pickaxePower = 471;
};

function get_gold_pickaxe(){
    pickaxePower=498;
};

function get_diamond_pickaxe(){
    pickaxePower=501;
};

/*function get_netherite_pickaxe(){
    pickaxePower=501;
};*/