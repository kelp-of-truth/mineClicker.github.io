// class作成
var itemsLength=0;
var itemsDataStrange=[];
class items {
    constructor(id, name, imageURL, itemType, rarity, count, def, itemNum) {
        this.id = id;
        this.name = name;
        this.imageURL = imageURL;
        this.itemType = itemType;
        this.rarity = rarity;
        this.count = count;

        itemsDataStrange[itemsLength]=this;

        itemsLength++;

        this.itemNum=itemsLength;
    }


    get ID() {
        return this.id;
    }
    get Name() {
        return this.name;
    }
    get ImageURL() {
        return this.imageURL;
    }
    get ItemType() {
        return this.ItemType;
    }
    get Rarity() {
        return this.rarity;
    }
    get Count() {
        return this.count;
    }

    get Length(){
        return this.itemNum;
    }


    set addCount(value) {
        this.count += value;
    }
    set subCount(value) {
        this.count -= value;
    }
}






/*class material{
    constructor(id, name, imageURL, count){
        this.id=id;
        this.name=name;
        this.imageURL=imageURL;
        this.count=count;
    }

    get Id(){
        return this.id;
    }
    get Name(){
        return this.name;
    }
    get ImageURL(){
        return this.imageURL;
    }
    get Count(){
        return this.count;
    }


    set subCount(value){
        this.count-=value;
    }
    set AddCount(value){
        this.count+=value;
    }
}*/






// ツルハシ
const wooden_pickaxe = new items("wooden_pickaxe", "wooden pickaxe", ".//img/textures/wooden_pickaxe.webp", "pickaxe", "common", 1);
const stone_pickaxe = new items("stone_pickaxe", "stone pickaxe", ".//img/textures/stone_pickaxe.webp", "pickaxe", "common", 0);
const iron_pickaxe = new items("iron_pickaxe", "iron pickaxe", ".//img/textures/iron_pickaxe.webp", "pickaxe", "uncommon", 0);
const gold_pickaxe = new items("gold_pickaxe", "gold pickaxe", ".//img/textures/gold_pickaxe.webp", "pickaxe", "uncommon", 0);
const diamond_pickaxe = new items("diamond_pickaxe", "diamond pickaxe", ".//img/textures/diamond_pickaxe.webp", "pickaxe", "uncommon", 0);
const netherite_pickaxe = new items("nethrite_pickaxe", "netherite pickaxe", ".//img/textures/netherite_pickaxe.webp", "pickaxe", "rare", 0);

// 作業アイテム
const furnace = new items("furnace", "furnace", ".//img/textures/furnace.webp", "craftItem", "common", 0);
const enchanting_table = new items("enchaning_table", "enchanting table", ".//img/textures/enchanting_table.webp", "craftItem", "common", 0);
const smithing_table = new items("smithing_table", "smithing table", ".//img/textures/smithing_table.webp", "craftItem", "common", 0);


// 素材系アイテム
const obsidian = new items("obsidian", "obsidian", ".//img/textures/obsidan.webp", "material", "uncommon", 0);
const book = new items("book", "book", ".//img/textures/book.webp", "material", "common", 0);
const leather = new items("leather", "leather", ".//img/textures/leather.webp", "material", "common", 0);
const paper = new items("paper", "paper", ".//img/textures/paper.webp", "material", "common", 0);
const sugar_cane = new items("sugar_cane", "sugar cane", ".//img/textures/sugar_cane.webp", "material", "common", 0);



// 鉱石
const cobblestone = new items("cobblestone", "cobblestone", ".//img/textures/cobblestone.webp", "ore", "common", 0);
const coal = new items("coal", "coal", ".//img/textures/coal.webp", "ore", "common", 0);
const iron_ingot = new items("iron_ingot", "iron ingot", ".//img/textures/iron_ingot.webp", "ore", "common", 0);
const gold_ingot = new items("gold_ingot", "gold ingot", ".//img/textures/gold_ingot.webp", "ore", "uncommon", 0);
const copper_ingot = new items("copper_ingot", "copper ingot", ".//img/textures/copper_ingot.webp", "ore", "common", 0);
const diamond = new items("diamond", "diamond", ".//img/textures/diamond.webp", "ore", "uncommon", 0);
const redstone_dust = new items("redstone_dust", "redstone dust", ".//img/textures/redstone_dust.webp", "ore", "common", 0);
const lapis_lazuli = new items("lapis_lazuli", "lapis lazuli", ".//img/textures/lapis_lazuli.webp", "ore", "common", 0);
const emerald = new items("emerald", "emerald", ".//img/textures/emerald.webp", "ore", "rare", 0);
const netherite_ingot = new items("netherite_ingot", "netherite ingot", ".//img/textures/netherite_ingot.webp", "ore", "rare", 0);




// 強化鉱石
const stone = new items("stone", "stone", ".//img/textures/stone.webp", "material", "uncommon", 0);
const cokes = new items("cokes", "cokes", ".//img/textures/cokes.webp", "material", "uncommon", 0);
const steel = new items('steel', "steel", ".//img/textures/steel.webp", "material", "rare", 0);
const royal_gold = new items("royal_gold", "royal gold", ".//img/textures/royal_gold.webp", "common", "epic", 0);
const rust_prevention_copper = new items('rust_prevention_copper_ingot', "rust prevention copper", ".//img/textures/rust_prevention_copper.webp", "material", "uncommon", 0);
const hardness_diamond = new items("hardness_diamond", "hardness diamond", ".//img/textures/hardness_diamond.webp", "material", "rare", 0);
const redstone_block = new items("redstone_block", "redstone block", ".//img/textures/restone_block.webp", "material", "uncommon", 0);
const enchanted_lapis_lazuli = new items('enchanted_lapis_lazuli', "enchanted lapos lazuli", ".//img/textures/enchanted_lapis_lazuli.webp", "material", "uncommon", 0);
const rich_man_s_block = new items("rich man's block", "rich man's block", ".//img/textures/rich_man_s_block.webp", "material", "epic", 0);
const ultimate_ingot = new items('ultimate_ingot', "ultimate ingot", ".//img/textures/ultimate_ingot.webp", "material", "epic", 0);