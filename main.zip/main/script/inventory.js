var playerStrage=[];

var storageL=0;

var emptySlot=0;
setInterval(() => {



    for(let i=0;i<itemsLength;i++){
        if(itemsDataStrange[i].Count>0){
            storageL++;
        };
    };
    if(storageL>27){
        inventorySize=storageL-storageL%9+9;
    };



    playerStrage="";
    playerStrage=[];

    for(let i=0;i<itemsLength;i++){
        emptyCheck(0);
        function emptyCheck(n){
            if(playerStrage[n]==undefined){
                emptySlot=n;
                if(itemsDataStrange[i].Count>=1){
                    playerStrage[emptySlot]=itemsDataStrange[i];
                };

            }else{
                n++;
                emptyCheck(n);
            }
            
        };




    };

}, 1);



var inventorySize=27;
inventorySize=itemsLength-itemsLength%9+9;
var inventoryTile=[];
var inventoryItemCount=[];
for(let i=0;i<inventorySize;i++){
    inventoryTile[inventoryTile.length]=document.createElement('img');
    inventoryItemCount[inventoryItemCount.length]=document.createElement('label');

    var thisIC=inventoryItemCount[inventoryItemCount.length-1];

    var thisIT=inventoryTile[inventoryTile.length-1];

    thisIT.classList.add("inventoryTile");
    thisIC.classList.add("inventoryItemCount")
    thisIC.innerHTML="";
    thisIT.src=".//img/textures/empty.webp";
    thisIT.style.left=((inventoryTile.length-1)%9)*54+"px";
    thisIT.style.bottom=((inventorySize-9)/9)*54-(Math.floor((inventoryTile.length-1)/9)*54)+"px";

    thisIC.style.left=((inventoryItemCount.length-1)%9)*54+"px";
    thisIC.style.bottom=((inventorySize-9)/9)*54-(Math.floor((inventoryItemCount.length-1)/9)*54)+"px";

    inventory.appendChild(thisIT);
    inventory.appendChild(thisIC)
};


setInterval(() => {
    for(let i=0;i<playerStrage.length;i++){
        inventoryTile[i].src=playerStrage[i].ImageURL;
        inventoryItemCount[i].innerHTML=playerStrage[i].Count;
    };
}, 10);


// for(let i=0;i<itemsLength;i++){
//     if(itemsDataStrange[i].Count<=0){
//         storageL++;
//     };
//     if(storageL==9){
//         for(let j=0;j<9;j){
//         inventoryTile[inventoryTile.length-1-j].hidden==true;
//     };};
// };














function openInv(){
    if(inventory.hidden==true){
        inventory.hidden=false;

    }else
    if(inventory.hidden==false){
        inventory.hidden=true;
    };
};